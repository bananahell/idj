Trabalho 1
Introdução a Desenvolvimento de Jogos
14/0065032 - Pedro Nogueira
Unb 2018/1


Meu repositório de trabalhos de IDJ:
  https://github.com/bananahell/idj

Link do github para o trabalho 1:
  https://github.com/bananahell/idj/tree/master/Trab1


Funcionamento do projeto

  Makefile disponível na pasta jogo_idj.
  Mesmos comandos, com diferença nas FLAGS de Warning: Warnings de variáveis não
    usadas estão agora aparecendo.
  Adicionados comandos cppcheck e valgrind (que já me arrependo). Disponíveis em
    make help.

  Estrutura de pastas é a mesma da orientada.
